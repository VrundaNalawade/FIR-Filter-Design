`timescale 1ns/1ps

module tb_fir_filter;

reg clk;
reg reset;
reg signed [7:0] x;
wire signed [7:0] y;

fir_filter uut (
    .clk(clk),
    .reset(reset),
    .x(x),
    .y(y)
);

// Clock generation
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Simulation
initial begin
    $dumpfile("Simulation/fir_filter.vcd");
    $dumpvars(0, tb_fir_filter);

    $monitor("Time=%0t reset=%b x=%d y=%d",
             $time, reset, x, y);

    reset = 1;
    x = 0;

    #20;
    reset = 0;

    #10 x = 10;
    #10 x = 20;
    #10 x = 30;
    #10 x = 40;
    #10 x = 0;
    #10 x = -10;
    #10 x = -20;
    #10 x = -30;
    #10 x = 0;

    #50;
    $finish;
end

endmodule
