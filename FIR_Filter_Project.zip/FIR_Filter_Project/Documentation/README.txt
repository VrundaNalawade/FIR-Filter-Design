FIR FILTER PROJECT

1. Project Name:
   Design and Simulation of FIR Filter using Verilog.

2. RTL Design:
   fir_filter.v

3. Testbench:
   tb_fir_filter.v

4. Simulation:
   Icarus Verilog

5. Waveform:
   GTKWave

6. Synthesis:
   Yosys

7. Results:
   FIR filter simulation completed.
   Waveform generated successfully.
   Synthesis completed successfully.
