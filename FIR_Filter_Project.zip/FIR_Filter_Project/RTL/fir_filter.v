module fir_filter (
    input wire clk,
    input wire reset,
    input wire signed [7:0] x,
    output reg signed [7:0] y
);

    reg signed [7:0] delay [0:6];

    wire signed [15:0] p0, p1, p2, p3;
    wire signed [15:0] p4, p5, p6, p7;
    wire signed [18:0] sum;

    assign p0 = x * 8'sd0;
    assign p1 = delay[0] * 8'sd5;
    assign p2 = delay[1] * 8'sd21;
    assign p3 = delay[2] * 8'sd38;
    assign p4 = delay[3] * 8'sd38;
    assign p5 = delay[4] * 8'sd21;
    assign p6 = delay[5] * 8'sd5;
    assign p7 = delay[6] * 8'sd0;

    assign sum =
        {{3{p0[15]}},p0} +
        {{3{p1[15]}},p1} +
        {{3{p2[15]}},p2} +
        {{3{p3[15]}},p3} +
        {{3{p4[15]}},p4} +
        {{3{p5[15]}},p5} +
        {{3{p6[15]}},p6} +
        {{3{p7[15]}},p7};

    wire signed [18:0] scaled;
    assign scaled = sum >>> 7;

    integer i;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            y <= 0;
            for (i = 0; i < 7; i = i + 1)
                delay[i] <= 0;
        end
        else begin
            if (scaled > 127)
                y <= 127;
            else if (scaled < -128)
                y <= -128;
            else
                y <= scaled[7:0];

            for (i = 6; i > 0; i = i - 1)
                delay[i] <= delay[i-1];

            delay[0] <= x;
        end
    end

endmodule
